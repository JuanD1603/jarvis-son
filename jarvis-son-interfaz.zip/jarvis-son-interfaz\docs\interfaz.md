# Interfaz gráfica (interfaz web local)

Jarvis-son V1 se puede usar desde el navegador del teléfono, sin terminal y sin internet. La interfaz es una página web local servida por el propio teléfono: el PC no participa.

## Cómo se abre

En Termux:

```bash
jarvis-web
```

El comando arranca el servidor, imprime la URL (`http://127.0.0.1:8080`) y abre el navegador con `termux-open-url`. Para detenerlo: `Ctrl+C` en Termux. Si el puerto 8080 ya está ocupado (por ejemplo, otro `jarvis-web` abierto), lo indica y termina.

Opciones: `--sin-abrir` (no abre el navegador; pruebas por SSH), `--puerto N`, `--wav ARCHIVO` (solo pruebas: cada turno procesa ese WAV en vez de grabar).

En la página: pulsar **Hablar**, esperar el aviso **¡Habla ahora!** y hablar durante los 5 s de grabación.

| Estado LISTO | Después de un turno |
|---|---|
| ![Interfaz en estado LISTO](img/interfaz_listo.png) | ![Interfaz después de un turno](img/interfaz_respuesta.png) |

Capturas con viewport de teléfono (390x844). La segunda corresponde a un turno real del pipeline con `tests/wav/frase_03.wav` (`jarvis-web --wav`), por eso la captura muestra `-`.

## Componentes

| Archivo | Función |
|---|---|
| `interfaz/servidor.py` | Servidor HTTP con la biblioteca estándar de Python 3 (`http.server`, `subprocess`, `threading`, `json`). Escucha solo en `127.0.0.1:8080`. |
| `interfaz/index.html` | Página única con CSS y JS en línea, sin CDN ni recursos externos. Modo claro/oscuro según el sistema. |
| `scripts/jarvis-web.sh` | Lanzador; se instala como `$PREFIX/bin/jarvis-web`. |
| `jarvis --una-vez` | Opción nueva del orquestador: un turno de voz con captura, sin leer stdin. Mismo código de salida que `--wav`; el turno queda en `turnos.csv` como modo `voz`. |
| `capturar.sh` | Crea `~/jarvis/tmp/grabando.flag` (vacío) en el instante del aviso "HABLA AHORA" y lo borra al terminar la grabación (también si falla, con `trap`). |

## Endpoints

| Método y ruta | Respuesta |
|---|---|
| `GET /` | `index.html` |
| `POST /api/turno` | `202` si inicia un turno; `409` si ya hay uno en curso. No acepta cuerpo (`400` si lo trae). Exige la cabecera `X-Jarvis: 1` (`403` sin ella o con un `Origin` ajeno). |
| `GET /api/eventos` | Server-Sent Events. Tipos: `hola` (estado al conectar), `inicio`, `estado`, `habla_ahora`, `grabacion_fin`, `transcripcion`, `respuesta`, `aviso`, `error` (etapa, causa, siguiente paso), `fin` (código de salida). |
| `GET /api/metricas` | JSON con el último turno (ms por etapa y total) y número de turnos, p50 y p95 del total para `voz` y para todos los modos. |

Las métricas se leen de `~/jarvis/logs/turnos.csv` con el mismo criterio que `tests/metricas.py`: turnos completos (código 0) y percentil por rango más cercano (función copiada). La interfaz no calcula ni guarda cifras propias.

## Flujo

```mermaid
sequenceDiagram
    participant P as Página (navegador)
    participant S as servidor.py
    participant J as jarvis --una-vez
    participant C as capturar.sh
    P->>S: POST /api/turno
    S-->>P: 202 (o 409 si hay un turno)
    S->>J: subprocess.Popen(argv en lista)
    J->>C: captura
    C-->>S: crea grabando.flag (sondeo cada 100 ms)
    S-->>P: SSE habla_ahora
    J-->>S: stdout [TRANSCRIBIENDO], Tú: ..., [GENERANDO], Jarvis-son: ..., [HABLANDO], [LISTO]
    S-->>P: SSE estado / transcripcion / respuesta
    J->>J: registra la fila en turnos.csv
    S-->>P: SSE fin
    P->>S: GET /api/metricas
```

## Seguridad

- El servidor solo escucha en `127.0.0.1`: no es accesible desde la red Wi-Fi ni desde otros equipos.
- El orquestador se ejecuta con `subprocess.Popen` y argv en lista (`shell=False`). No hay `shell=True`, `os.system` ni comandos construidos con texto.
- El cliente no envía texto: el botón solo dispara el turno y `POST /api/turno` rechaza cualquier cuerpo.
- Otra página abierta en el navegador del teléfono no puede activar el micrófono: `POST /api/turno` exige la cabecera `X-Jarvis: 1`, que un sitio ajeno no puede enviar sin una verificación CORS que el servidor nunca aprueba, y se rechazan `Origin` ajenos.
- Solo se aceptan peticiones con `Host` `127.0.0.1:8080` o `localhost:8080` (defensa contra DNS rebinding).
- La página usa una Content-Security-Policy sin orígenes externos y muestra los textos con `textContent` (sin inyección de HTML).
- Un `threading.Lock` garantiza un solo turno a la vez.

## Privacidad

- El historial de la conversación vive solo en la memoria de la página: no se guarda en disco y se borra al recargar.
- El servidor no escribe archivos de texto ni de audio. Los temporales del turno los sigue borrando el orquestador; `turnos.csv` solo guarda tiempos y número de caracteres.
- El registro del servidor (`log` HTTP en la salida de Termux) contiene rutas y códigos, nunca el texto de la conversación.

## Limitaciones

- Un turno a la vez y sin barge-in: el botón queda desactivado hasta que Jarvis-son termina de hablar.
- La latencia es la misma que por terminal (la interfaz solo añade el arranque del proceso `jarvis`, que es despreciable frente al SLM y al TTS).
- El servidor debe quedar abierto en Termux mientras se usa la página. Si Android suspende Termux en segundo plano, la página muestra "Sin conexión con jarvis-web".
- El aviso "¡Habla ahora!" depende de `grabando.flag`; si `capturar.sh` muere por timeout del orquestador (SIGKILL), el servidor borra el marcador huérfano al iniciar el siguiente turno.
