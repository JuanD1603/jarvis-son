#!/usr/bin/env python3
"""Interfaz web local de Jarvis-son V1 (solo biblioteca estándar).

Sirve index.html, lanza un turno de voz con `jarvis --una-vez` y retransmite por Server-Sent Events
lo que imprime el orquestador. Escucha solo en 127.0.0.1: no es accesible desde otros equipos.

Uso: servidor.py [--puerto 8080] [--wav ARCHIVO]
  --wav ARCHIVO  (solo pruebas) cada turno procesa este WAV con `jarvis --wav` en vez de grabar.
Variables: JARVIS_HOME (por defecto ~/jarvis).
"""
import argparse
import csv
import errno
import json
import math
import os
import queue
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
J = Path(os.environ.get("JARVIS_HOME", str(Path.home() / "jarvis")))
BINARIO = J / "bin" / "jarvis"
CSV_TURNOS = J / "logs" / "turnos.csv"
MARCADOR = J / "tmp" / "grabando.flag"
INDEX = Path(__file__).resolve().parent / "index.html"
ETAPAS = ["captura", "stt", "slm", "tts", "reproduccion"]
ESTADOS = {"LISTO", "GRABANDO", "TRANSCRIBIENDO", "GENERANDO", "HABLANDO", "ERROR"}


def percentil(valores: list[float], p: float) -> float:
    """Copia de tests/metricas.py: rango más cercano (nearest-rank), sin interpolación."""
    datos = sorted(valores)
    if not datos:
        return float("nan")
    rango = max(1, math.ceil(p / 100 * len(datos)))
    return datos[rango - 1]


def resumen_metricas() -> dict:
    """Último turno y p50/p95 del turno total, con el mismo criterio que tests/metricas.py."""
    try:
        with open(CSV_TURNOS, encoding="utf-8", newline="") as f:
            filas = list(csv.DictReader(f))
    except FileNotFoundError:
        filas = []

    def resumen(grupo: list[dict]) -> dict:
        ok = [r for r in grupo if r.get("codigo") == "0"]
        ms = [float(r["ms_total"]) for r in ok if float(r["ms_total"]) > 0]
        return {
            "turnos": len(grupo),
            "completos": len(ok),
            "p50_total_ms": round(percentil(ms, 50)) if ms else None,
            "p95_total_ms": round(percentil(ms, 95)) if ms else None,
        }

    ultimo = None
    if filas:
        r = filas[-1]
        ultimo = {
            "id": int(r["id"]),
            "timestamp": r["timestamp"],
            "modo": r["modo"],
            "codigo": int(r["codigo"]),
            "etapa_error": r["etapa_error"],
            "ms": {e: int(r[f"ms_{e}"]) for e in ETAPAS + ["total"]},
        }
    return {
        "ultimo": ultimo,
        "todos": resumen(filas),
        "voz": resumen([r for r in filas if r.get("modo") == "voz"]),
    }


class Difusor:
    """Reparte cada evento a todas las conexiones SSE abiertas."""

    def __init__(self) -> None:
        self._colas: set[queue.Queue] = set()
        self._lock = threading.Lock()

    def suscribir(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=200)
        with self._lock:
            self._colas.add(q)
        return q

    def cancelar(self, q: queue.Queue) -> None:
        with self._lock:
            self._colas.discard(q)

    def emitir(self, tipo: str, **datos) -> None:
        mensaje = json.dumps({"tipo": tipo, **datos}, ensure_ascii=False)
        with self._lock:
            colas = list(self._colas)
        for q in colas:
            try:
                q.put_nowait(mensaje)
            except queue.Full:
                # Cliente que no lee (pestaña congelada): se descarta para no frenar el turno.
                self.cancelar(q)


class Turnos:
    """Ejecuta un único turno a la vez (la V1 es secuencial) y traduce su salida a eventos."""

    def __init__(self, difusor: Difusor, wav_prueba: str | None) -> None:
        self.difusor = difusor
        self.wav_prueba = wav_prueba
        self.lock = threading.Lock()
        self.estado = "LISTO"

    def iniciar(self) -> bool:
        if not self.lock.acquire(blocking=False):
            return False
        try:
            threading.Thread(target=self._ejecutar, daemon=True).start()
        except BaseException:
            self.lock.release()
            raise
        return True

    def en_curso(self) -> bool:
        return self.lock.locked()

    def _argv(self) -> list[str]:
        if self.wav_prueba:
            return [str(BINARIO), "--wav", self.wav_prueba]
        return [str(BINARIO), "--una-vez"]

    def _vigilar_marcador(self, fin: threading.Event) -> None:
        grabando = False
        while not fin.is_set():
            ahora = MARCADOR.exists()
            if ahora != grabando:
                grabando = ahora
                self.difusor.emitir("habla_ahora" if ahora else "grabacion_fin")
            fin.wait(0.1)
        if grabando:
            self.difusor.emitir("grabacion_fin")

    def _ejecutar(self) -> None:
        fin = threading.Event()
        try:
            # Un marcador huérfano (captura terminada con SIGKILL por timeout) daría un aviso falso.
            try:
                MARCADOR.unlink()
            except FileNotFoundError:
                pass
            self.difusor.emitir("inicio")
            threading.Thread(target=self._vigilar_marcador, args=(fin,), daemon=True).start()
            codigo, error_emitido, ultimas = self._leer_orquestador()
            if codigo != 0 and not error_emitido:
                self.difusor.emitir(
                    "error",
                    etapa="orquestador",
                    causa=f"terminó con código {codigo}" + (f": {ultimas[-1]}" if ultimas else ""),
                    siguiente="Ejecuta `jarvis` en Termux para ver el detalle completo.",
                )
            self.difusor.emitir("fin", codigo=codigo)
        finally:
            fin.set()
            self.estado = "LISTO"
            self.lock.release()

    def _leer_orquestador(self) -> tuple[int, bool, list[str]]:
        error: dict[str, str] = {}
        error_emitido = False
        ultimas: list[str] = []
        try:
            # argv en lista y sin shell: el cliente nunca aporta texto a este comando.
            proc = subprocess.Popen(
                self._argv(),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
        except OSError as e:
            self.difusor.emitir(
                "error",
                etapa="orquestador",
                causa=f"no se pudo ejecutar {BINARIO}: {e.strerror}",
                siguiente="Instala Jarvis-son con scripts/instalar_termux.sh.",
            )
            return 127, True, []
        assert proc.stdout is not None
        for cruda in proc.stdout:
            linea = cruda.rstrip("\n")
            texto = linea.strip()
            if texto.startswith("[") and texto.endswith("]") and texto[1:-1] in ESTADOS:
                self.estado = texto[1:-1]
                self.difusor.emitir("estado", estado=self.estado)
            elif linea.startswith("  Tú: "):
                self.difusor.emitir("transcripcion", texto=linea[len("  Tú: "):])
            elif linea.startswith("  Jarvis-son: "):
                self.difusor.emitir("respuesta", texto=linea[len("  Jarvis-son: "):])
            elif self.estado == "ERROR" and texto.startswith(("etapa: ", "causa: ", "siguiente paso: ")):
                clave, valor = texto.split(": ", 1)
                error[clave] = valor
                if clave == "siguiente paso":
                    self.difusor.emitir(
                        "error", etapa=error.get("etapa", ""), causa=error.get("causa", ""), siguiente=valor
                    )
                    error_emitido = True
                    error = {}
            elif texto in ("No te escuché, intenta de nuevo.", "(TTS no generó audio)"):
                self.difusor.emitir("aviso", texto=texto)
            elif texto:
                ultimas = (ultimas + [texto])[-5:]
        return proc.wait(), error_emitido, ultimas


class Manejador(BaseHTTPRequestHandler):
    server_version = "JarvisSon/1"
    turnos: Turnos
    difusor: Difusor
    puerto: int

    def log_message(self, formato: str, *args) -> None:
        sys.stderr.write(f"{time.strftime('%H:%M:%S')} {formato % args}\n")

    def _host_valido(self) -> bool:
        # Defensa contra DNS rebinding: solo se aceptan nombres locales.
        return self.headers.get("Host", "") in (f"127.0.0.1:{self.puerto}", f"localhost:{self.puerto}")

    def _cabeceras_comunes(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")

    def _json(self, codigo: int, datos: dict) -> None:
        cuerpo = json.dumps(datos, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self._cabeceras_comunes()
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self) -> None:
        if not self._host_valido():
            self._json(403, {"error": "host no permitido"})
            return
        ruta = self.path.split("?", 1)[0]
        if ruta in ("/", "/index.html"):
            self._index()
        elif ruta == "/api/metricas":
            self._json(200, resumen_metricas())
        elif ruta == "/api/eventos":
            self._eventos()
        else:
            self._json(404, {"error": "no encontrado"})

    def do_POST(self) -> None:
        if not self._host_valido():
            self._json(403, {"error": "host no permitido"})
            return
        if self.path.split("?", 1)[0] != "/api/turno":
            self._json(404, {"error": "no encontrado"})
            return
        # Una página ajena abierta en el teléfono no puede enviar esta cabecera sin una verificación
        # previa (CORS) que este servidor nunca aprueba: evita que otro sitio active el micrófono.
        origen = self.headers.get("Origin")
        locales = (f"http://127.0.0.1:{self.puerto}", f"http://localhost:{self.puerto}")
        if self.headers.get("X-Jarvis") != "1" or (origen is not None and origen not in locales):
            self._json(403, {"error": "origen no permitido"})
            return
        if (self.headers.get("Content-Length") or "0").strip() != "0" or self.headers.get("Transfer-Encoding"):
            self._json(400, {"error": "este endpoint no acepta texto"})
            return
        if not self.turnos.iniciar():
            self._json(409, {"error": "ya hay un turno en curso"})
            return
        self._json(202, {"ok": True})

    def _index(self) -> None:
        cuerpo = INDEX.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
            "connect-src 'self'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        )
        self._cabeceras_comunes()
        self.end_headers()
        self.wfile.write(cuerpo)

    def _eventos(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self._cabeceras_comunes()
        self.end_headers()
        q = self.difusor.suscribir()
        try:
            inicial = json.dumps(
                {"tipo": "hola", "estado": self.turnos.estado, "en_curso": self.turnos.en_curso()},
                ensure_ascii=False,
            )
            self.wfile.write(f"data: {inicial}\n\n".encode("utf-8"))
            self.wfile.flush()
            while True:
                try:
                    mensaje = q.get(timeout=15)
                    bloque = f"data: {mensaje}\n\n"
                except queue.Empty:
                    bloque = ": ping\n\n"  # mantiene viva la conexión y detecta clientes cerrados
                self.wfile.write(bloque.encode("utf-8"))
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        finally:
            self.difusor.cancelar(q)


def main() -> int:
    ap = argparse.ArgumentParser(description="Interfaz web local de Jarvis-son V1")
    ap.add_argument("--puerto", type=int, default=8080)
    ap.add_argument("--wav", help="solo pruebas: procesa este WAV en cada turno en vez de grabar")
    a = ap.parse_args()
    if a.wav and not Path(a.wav).is_file():
        print(f"ERROR: no existe el WAV de prueba: {a.wav}", file=sys.stderr)
        return 66

    difusor = Difusor()
    Manejador.difusor = difusor
    Manejador.turnos = Turnos(difusor, a.wav)
    Manejador.puerto = a.puerto
    try:
        servidor = ThreadingHTTPServer((HOST, a.puerto), Manejador)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            print(
                f"ERROR: el puerto {a.puerto} ya está ocupado. ¿Ya hay un jarvis-web abierto en otra "
                f"sesión de Termux? Ciérralo con Ctrl+C o usa otro puerto (--puerto).",
                file=sys.stderr,
            )
            return 2
        raise
    print(f"Jarvis-son web escuchando en http://{HOST}:{a.puerto} (solo este teléfono)", flush=True)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        servidor.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
