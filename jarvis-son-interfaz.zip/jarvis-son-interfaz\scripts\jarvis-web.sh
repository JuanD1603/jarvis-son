#!/data/data/com.termux/files/usr/bin/bash
# Abre la interfaz web local de Jarvis-son: arranca interfaz/servidor.py y abre el navegador.
# Uso: jarvis-web [--sin-abrir] [--puerto N] [--wav ARCHIVO]
#   --sin-abrir    no abre el navegador (pruebas por SSH)
#   --wav ARCHIVO  solo pruebas: cada turno procesa este WAV en vez de grabar
# Se instala como el comando "jarvis-web" (scripts/instalar_termux.sh).
set -u
J="${JARVIS_HOME:-$HOME/jarvis}"
PUERTO=8080
ABRIR=1
EXTRA=()

uso() { sed -n '3,5p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
  case "$1" in
    --sin-abrir) ABRIR=0 ;;
    --puerto) PUERTO="${2:-}"; shift ;;
    --wav) EXTRA+=(--wav "${2:-}"); shift ;;
    -h|--help) uso; exit 0 ;;
    *) echo "argumento desconocido: $1" >&2; uso >&2; exit 64 ;;
  esac
  shift
done
case "$PUERTO" in ''|*[!0-9]*) echo "puerto inválido: $PUERTO" >&2; exit 64 ;; esac

SERVIDOR="$J/interfaz/servidor.py"
[ -f "$SERVIDOR" ] || { echo "ERROR: no existe $SERVIDOR. Ejecuta scripts/instalar_termux.sh" >&2; exit 66; }
URL="http://127.0.0.1:$PUERTO"

python3 "$SERVIDOR" --puerto "$PUERTO" "${EXTRA[@]}" &
PID=$!
trap 'kill "$PID" 2>/dev/null; wait "$PID" 2>/dev/null; echo; echo "jarvis-web detenido."' INT TERM

# Espera a que el servidor responda; si termina antes (puerto ocupado), su mensaje ya se imprimió.
for _ in $(seq 1 50); do
  if ! kill -0 "$PID" 2>/dev/null; then
    wait "$PID"; exit $?
  fi
  curl -s -o /dev/null "$URL/api/metricas" && break
  sleep 0.1
done

echo "Interfaz de Jarvis-son: $URL"
echo "Para detener el servidor: Ctrl+C en esta ventana de Termux."
if [ "$ABRIR" = "1" ]; then
  termux-open-url "$URL" || echo "No se pudo abrir el navegador: abre $URL a mano." >&2
fi
wait "$PID"
